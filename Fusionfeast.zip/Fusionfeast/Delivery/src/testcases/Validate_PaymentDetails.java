package testcases;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import Helper.BrowserFactory;
import Pages.Login_pageNew;
 
public class Validate_PaymentDetails {
 
    @Test
    public void check() {
    WebDriver driver=BrowserFactory.start_browser("Firefox","http://localhost/Fusion_fiest/payment.php");
    Login_pageNew login=PageFactory.initElements(driver, Login_pageNew.class);
    login.payment("Saloni","9273649823","rohtak,haryana","225004");
    login.Fordot_pwd_FB();
 
   
 
    }
}