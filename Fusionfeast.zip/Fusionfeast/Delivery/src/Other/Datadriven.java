package Other;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;

public class Datadriven {
		WebDriver driver;
		String Baseurl= "http://localhost/Fusion_fiest/payment.php";
		
		@Before
		  public void setUp() throws Exception {
		
		driver= new FirefoxDriver();
		driver.get(Baseurl);
		}
		@Test
		 public void testWeb() throws Exception {
		    driver.findElement(By.name("name")).isDisplayed();
			driver.findElement(By.name("name")).sendKeys("Sona");
		    
			driver.findElement(By.name("num")).isDisplayed();
			driver.findElement(By.name("num")).sendKeys("8130336086");
            
			driver.findElement(By.name("address")).isDisplayed();
		    driver.findElement(By.name("address")).sendKeys("delhi");
		 
		    driver.findElement(By.name("pin")).sendKeys("110032");
            
		    driver.findElement(By.name("submit")).click();
		}
		  @After
		  public void tearDown() throws Exception {
            driver.quit();
		  }
	}
