package Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
 
public class Login_pageNew {
 
    WebDriver driver;
    public Login_pageNew(WebDriver driver) {
        this.driver= driver;
                }
    @FindBy(name= "name")
    @CacheLookup
    WebElement name;
   
    @FindBy(how=How.NAME, using= "num")
    @CacheLookup
    WebElement num1;
    @FindBy(how=How.NAME, using= "address")
    @CacheLookup
    WebElement address;
    @FindBy(how=How.NAME, using= "pin")
    @CacheLookup
    WebElement pin1;
    @FindBy(how=How.NAME, using= "submit")
    @CacheLookup
    WebElement submit;
   
   
    public void payment(String nam, String numb, String addr, String pinc) {
        name.sendKeys(nam);
        num1.sendKeys(numb);
        address.sendKeys(addr);
        pin1.sendKeys(pinc);
    }
   
   
       public void Fordot_pwd_FB() {
        submit.click();
    }}