package snippet;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;

public class login {

	public WebDriver driver;
	By uname= By.name("email");
	@Test
	public void FBLogin() {
		driver= new FirefoxDriver();
		driver.get("http://localhost/Fusion_fiest/payment.php");
		driver.manage().window().maximize();

		driver.findElement(By.name("name")).sendKeys("Sona");
	    
		driver.findElement(By.name("num")).sendKeys("8130336086");
        
	    driver.findElement(By.name("address")).sendKeys("delhi");
	 
	    driver.findElement(By.name("pin")).sendKeys("110032");
        
	    driver.findElement(By.name("submit")).click();
	}
	public void onTestFailure(ITestResult obj) {
	System.out.println("Screenshot captured"+obj.toString());
}
	public void onTestStart(ITestResult obj) {
System.out.println("Testcase started"+ obj.toString());
}
	public void onTestSuccess(ITestResult obj) {
	System.out.println("Congrats Test case has been passed"+ obj.toString());
}
}
