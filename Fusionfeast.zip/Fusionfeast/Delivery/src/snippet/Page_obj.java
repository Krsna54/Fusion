package snippet;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_obj {
	
	WebDriver driver;
	
public Page_obj(WebDriver driver) {
		this.driver= driver;
	}
	
	public void typeusername() {
		driver.findElement(By.name("name")).sendKeys("Sona");
	}
	public void typeemail() {
		driver.findElement(By.name("num")).sendKeys("8130336086");
		}
	
public void typeaddress() {

driver.findElement(By.name("address")).sendKeys("delhi");

}
public void typepin() {
	driver.findElement(By.name("pin")).sendKeys("110032");
	}
public void clickbutton() {

driver.findElement(By.name("submit")).click();
driver.close();
}
}

