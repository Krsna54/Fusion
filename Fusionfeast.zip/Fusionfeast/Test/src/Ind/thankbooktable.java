package Ind;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebDriver;

public class thankbooktable {
	private WebDriver driver;
	String Baseurl= "http://localhost/Fusion_fiest/thankyou.html";
    boolean thank;
	boolean link;
	@Before
	public void setUp() throws Exception {
		
	
	 driver= new FirefoxDriver();

	driver.get(Baseurl);
    driver.manage().window().maximize();
	}
    @Test
    public void testWeb() throws Exception {
	thank= driver.findElement(By.tagName("h2")).isDisplayed();
    System.out.println(thank);
    driver.findElement(By.tagName("h2")).getText();
	link=driver.findElement(By.xpath("/html/body/div/form/p[3]/a")).isDisplayed();
	
    System.out.println("Link of restaurant is present");


		
	driver.findElement(By.xpath("/html/body/div/form/button/a")).click();
}

	@After
	public void tearDown() throws Exception {
     driver.close();
}

}
