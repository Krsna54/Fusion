package Ind;
 
import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.CacheLookup;
 
public class Index {

	 private WebDriver driver;

	  public static String baseUrl = "http://localhost/Fusion_fiest/";

	  private boolean acceptNextAlert = true;

	  private StringBuffer verificationErrors = new StringBuffer();

	  public Integer passCount = 0;

	  public Integer totalCount = 3;

	  public static boolean isButton1Present = false;

	  public static boolean isButton2Present = false;

	  public static boolean isButton3Present = false;

	  public static boolean isOrderButtonPresent = false;

	  public static boolean isTableButtonPresent = false;

	  public static boolean isSubmitButtonPresent = false;

	  public static boolean isHeaderPresent = false;

	  public static boolean isFooterPresent = false;

	  public static boolean isDivPresent = false;

	  public static boolean isMenuPresent = false;

	  public static boolean isFeedbackPresent = false;

	  public static boolean ismenuPresent = false;

	  public static boolean isBookPresent = false;

	  public static String elem1 = "";

	  public static String elem2 = "";

	  public static String menu = "";

	  public static String book ="";

	@Before

	  public void setUp() throws Exception {

		  driver = new FirefoxDriver();

			driver.get(baseUrl);

	  }
 
 
	  @Test

	  public void testWeb() throws Exception {

	driver.findElement(By.xpath("/html/body/form/nav/ul/li[1]/a")).click();

	isHeaderPresent=driver.findElement(By.xpath("/html/body/form/nav")).isDisplayed();

	System.out.println("Navbar is present "+isHeaderPresent);

	isDivPresent=driver.findElement(By.xpath("/html/body/form/div")).isDisplayed();

	System.out.println("Hidding is present "+isDivPresent);

	elem1=driver.findElement(By.xpath("/html/body/form/div/div/div[1]/div/p[1]")).getText();

	System.out.println(elem1);

	isOrderButtonPresent=driver.findElement(By.xpath("/html/body/form/div/div/div[2]/button[1]/a")).isDisplayed();

	System.out.println("Order button is present "+isOrderButtonPresent);

	isTableButtonPresent=driver.findElement(By.xpath("/html/body/form/div/div/div[2]/button[2]/a")).isDisplayed();

	System.out.println("Table book button is present "+isTableButtonPresent);

	isMenuPresent=driver.findElement(By.xpath("/html/body/form/section[1]")).isDisplayed();

	System.out.println("menu headder is present "+isMenuPresent);

	isButton1Present=driver.findElement(By.xpath("/html/body/form/section[1]/div/div/div[1]/div/div/a")).isDisplayed();

	System.out.println("more button is present "+isButton1Present);

	isButton2Present=driver.findElement(By.xpath("/html/body/form/section[1]/div/div/div[2]/div/div/a")).isDisplayed();

	System.out.println("more button is present "+isButton2Present);

	isButton3Present=driver.findElement(By.xpath("/html/body/form/section[1]/div/div/div[3]/div/div/a")).isDisplayed();

	System.out.println("more button is present "+isButton3Present);

	isFeedbackPresent=driver.findElement(By.xpath("/html/body/form/section[2]")).isDisplayed();

	System.out.println("Feedback is present "+isFeedbackPresent);

	elem2=driver.findElement(By.xpath("/html/body/form/section[2]/div[1]")).getText();

	System.out.println(elem2);

	isSubmitButtonPresent=driver.findElement(By.xpath("/html/body/form/section[2]/div[24]/button")).isDisplayed();

	System.out.println("Submit button is present "+isSubmitButtonPresent);

	isFooterPresent=driver.findElement(By.xpath("/html/body/form/footer")).isDisplayed();

	System.out.println("Footer is present "+isFooterPresent);

	driver.findElement(By.xpath("/html/body/form/div/div/div[2]/button[1]/a")).click();

	ismenuPresent=driver.findElement(By.xpath("/html/body/div[1]")).isDisplayed();

	System.out.println("Menu is present "+ismenuPresent);

	menu=driver.findElement(By.xpath("/html/body/div[1]")).getText();

	System.out.println(menu);

	driver.navigate().back();

	driver.findElement(By.xpath("/html/body/form/div/div/div[2]/button[2]/a")).click();

	isBookPresent=driver.findElement(By.xpath("/html/body/form/div/div")).isDisplayed();

	System.out.println("Book Table is present "+isBookPresent);

	book=driver.findElement(By.xpath("/html/body/form/div/div")).getText();

	System.out.println(book);

	driver.navigate().back();

	  }
 
	   @After

	  public void tearDown() throws Exception {

		driver.quit();

	  }
 
	}
 