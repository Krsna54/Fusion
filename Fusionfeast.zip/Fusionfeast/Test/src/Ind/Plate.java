package Ind;

	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;
	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.firefox.FirefoxDriver;
	public class Plate {
		 public static WebDriver driver;
		  public static String baseUrl = "http://localhost/fusion_Fiest%202/Fusion_fiest/plate.php";
		  public static boolean isHeadingPresent = false;
		  public static boolean ProceedButton = false;
		  public static boolean ClearButton = false;
		  
		  @Before
		  public void setUp() throws Exception {
			  driver = new FirefoxDriver();
			  driver.get(baseUrl);
	}  
	@Test
	public void testWeb() throws Exception{
		 driver.manage().window().maximize();
	   isHeadingPresent = driver.findElement(By.xpath("/html/body/div/p")).isDisplayed();
	   System.out.println(isHeadingPresent);
	   ProceedButton = driver.findElement(By.xpath("/html/body/div/div[2]/form/button[1]/a")).isDisplayed();
	   System.out.println(ProceedButton);
	   ClearButton = driver.findElement(By.xpath("/html/body/div/div[2]/form/button[2]")).isDisplayed();
	   System.out.println(ClearButton);
	   driver.findElement(By.xpath("/html/body/div/div[2]/form/button[2]")).click();
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("/html/body/div/div[2]/form/button[1]/a")).click();
	   Thread.sleep(3000);
	   }
	@After
	public void tearDown() throws Exception{
		   driver.quit();
	 
	}}
