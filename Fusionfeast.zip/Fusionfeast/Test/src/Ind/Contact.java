package Ind;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;

public class Contact {

	 private WebDriver driver;

	 public static String baseUrl = "http://localhost/Fusion_fiest/";

	 public static boolean isHeaderPresent = false;

	 public static boolean isContactPresent = false;

	 public static boolean isContactmenuPresent = false;

	 public static boolean isContactaboutPresent = false;

	 public static boolean isContactreviewPresent = false;

	 public static boolean isContactplatePresent = false;

	 public static boolean isContactbookPresent = false;

	 public static String contact ="";

	 public static String contactmenu ="";

	 public static String contactabout = "";

	 public static String contactreview="";

	 public static String contactplate="";

	 public static String contactbook="";

	 @Before

	  public void setUp() throws Exception {

		  driver = new FirefoxDriver();

			driver.get(baseUrl);

	  }

	 @Test

	  public void testWeb() throws Exception {

		isHeaderPresent=driver.findElement(By.xpath("/html/body/form/nav")).isDisplayed();

		System.out.println("Navbar is present "+isHeaderPresent);

		driver.findElement(By.xpath("/html/body/form/nav/ul/li[4]/a")).click();

		isContactPresent=driver.findElement(By.xpath("/html/body/form/footer/div")).isDisplayed();

		System.out.println("Contact us present in home page "+isContactPresent);

		contact = driver.findElement(By.xpath("/html/body/form/footer/div/div[1]/div[1]/h4")).getText();

		System.out.println(contact);

		driver.navigate().to("http://localhost/Fusion_fiest/menu.html");

		driver.findElement(By.xpath("/html/body/nav/ul/li[4]")).click();

		isContactmenuPresent = driver.findElement(By.xpath("/html/body/footer")).isDisplayed();

		System.out.println("Contact us present in menu page "+isContactmenuPresent);

		contactmenu = driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[1]/h4")).getText();

		System.out.println(contactmenu);

		driver.navigate().to("http://localhost/Fusion_fiest/about.html");

		driver.findElement(By.xpath("/html/body/nav/ul/li[4]/a")).click();

		isContactaboutPresent = driver.findElement(By.xpath("/html/body/footer/div")).isDisplayed();

		System.out.println("Contact us present in about us page "+isContactaboutPresent);

		contactabout = driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[1]/h4")).getText();

		System.out.println(contactabout);

		driver.navigate().to("http://localhost/Fusion_fiest/review.php");

		driver.findElement(By.xpath("/html/body/form/nav/ul/li[4]")).click();

		isContactreviewPresent = driver.findElement(By.xpath("/html/body/form/footer/div")).isDisplayed();

		System.out.println("Contact us present in about us page "+isContactreviewPresent);

		contactreview = driver.findElement(By.xpath("/html/body/form/footer/div/div[1]/div[1]/h4")).getText();

		System.out.println(contactreview);

 
		driver.navigate().to("http://localhost/Fusion_fiest/plate.php");

		driver.findElement(By.xpath("/html/body/nav/ul/li[4]")).click();

		isContactplatePresent = driver.findElement(By.xpath("/html/body/footer/div")).isDisplayed();

		System.out.println("Contact us present in plate page "+isContactplatePresent);

		contactplate = driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[1]/h4")).getText();

		System.out.println(contactplate);

		driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/ul/li[1]/a")).click();

		System.out.println("Tweeter is opened");

		driver.navigate();

		driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/ul/li[2]/a")).click();

		System.out.println("Facebook is opend");

		driver.navigate();

		driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/ul/li[3]/a")).click();

		System.out.println("Instagram is opened");

		driver.navigate();

		driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[2]/ul/li[4]/a")).click();

		System.out.println("Youtube is opend");

		driver.navigate();

		driver.findElement(By.xpath("/html/body/footer/div/div[1]/div[3]/div/a")).click();

		System.out.println("Whatsapp is opened");

		driver.navigate();

		}

	 @After

	  public void tearDown() throws Exception {

		driver.quit();

	  }

}
