package Ind;

import java.util.List;

import java.util.concurrent.TimeUnit;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
 
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.interactions.Actions;

public class Menu {

  public static WebDriver driver;

  public static String baseUrl = "http://localhost/fusion_Fiest%202/Fusion_fiest/menu.html";

  public static boolean isHeaderPresent = false;

  public static boolean isHeader1Present = false;

  public static boolean isAddButtonPresent = false;

  public static boolean isAboutButtonPresent = false;

  public static boolean isSaladButtonPresent = false;

  @Before

  public void setUp() throws Exception {

	  driver = new FirefoxDriver();

	  driver.get(baseUrl);

	  }

  @Test

  public void testWeb() throws Exception{

	  driver.manage().window().maximize();

	  isHeaderPresent = driver.findElement(By.id("Menu")).isDisplayed();

	  System.out.println(isHeaderPresent);

	  driver.findElement(By.xpath("/html/body/div[2]/ul/li[3]/a")).click();

	  Thread.sleep(3000);

	  driver.navigate().refresh();

	  Thread.sleep(2000);

	  isAddButtonPresent = driver.findElement(By.xpath("/html/body/div[3]/section[1]/div/div/div[1]/div[1]/div/div/button[1]")).isDisplayed();

	  System.out.println(isAddButtonPresent);

	  isAboutButtonPresent = driver.findElement(By.xpath("/html/body/div[3]/section[1]/div/div/div[1]/div[1]/div/div/button[2]")).isDisplayed();

	  System.out.println(isAboutButtonPresent);

	  isHeader1Present = driver.findElement(By.tagName("h2")).isDisplayed();

	  System.out.println(isHeader1Present);

	  Thread.sleep(6000);

  }

   @After

   public void tearDown() throws Exception{ 

	   driver.quit(); 

   }

}
 