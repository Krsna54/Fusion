package Ind;
	 
	import org.junit.After;
	import org.junit.Before;
	import org.junit.Test;
	import org.openqa.selenium.By;
	import org.openqa.selenium.firefox.FirefoxDriver;
	import org.openqa.selenium.WebDriver;
	 
	public class thankorder {
	 
		private WebDriver driver;
			public static String Baseurl= "http://localhost/Fusion_fiest/thank.html";
	        public static boolean tag;
	        public static String text;
			@Before
			public void setUp() throws Exception {
				
			
			driver= new FirefoxDriver();
	 
			driver.get(Baseurl);
	        driver.manage().window().maximize();
			}
	        @Test
	        public void testWeb ()throws Exception{
			tag=driver.findElement(By.tagName("h1")).isDisplayed();
			
	        System.out.println(tag);
	        text=driver.findElement(By.tagName("h1")).getText();
	       
	        System.out.println(text);
			driver.findElement(By.xpath("/html/body/div/form/div/div/div/div/a")).click();
			
			
	}
	 
			@After
			public void tearDown() throws Exception {
	         driver.close();
		}
	 
		}
	
