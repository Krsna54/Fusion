package Ind;
 
 
import java.util.concurrent.TimeUnit;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.openqa.selenium.interactions.Actions;

public class About {

  public static WebDriver driver;

  public static String baseUrl = "http://localhost/Fusion_fiest/about.html";

  public static boolean isDivPresent = false;

  public static boolean isTeamPresent = false;

  public static boolean isAboutUsPresent = false;

  @Before

  public void setUp() throws Exception {

	  driver = new FirefoxDriver();

	  driver.get(baseUrl);

	  }

  @Test

  public void testWeb() throws Exception{

	  driver.manage().window().maximize();

	 isDivPresent= driver.findElement(By.xpath("/html/body/section/div[1]")).isDisplayed();

	 System.out.println(isDivPresent);

	 Thread.sleep(3000);

	  isTeamPresent = driver.findElement(By.xpath("/html/body/section/div[3]/div[4]/p")).isDisplayed();

	  System.out.println(isTeamPresent);

	  isAboutUsPresent = driver.findElement(By.xpath("/html/body/section/section[2]/p[1]")).isDisplayed();

	  System.out.println(isAboutUsPresent);

	  Thread.sleep(6000);

  }

   @After

   public void tearDown() throws Exception{ 

	   driver.quit(); 

   }

}

