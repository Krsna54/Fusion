package Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Login_pageNew {

	WebDriver driver;
    public Login_pageNew(WebDriver driver) {
        this.driver= driver;
                }
    @FindBy(name= "name")
    @CacheLookup
    WebElement name;
    @FindBy(how=How.NAME, using= "email")
    @CacheLookup
    WebElement email;
    @FindBy(how=How.NAME, using= "feedback")
    @CacheLookup
    WebElement feedback;
    @FindBy(how= How.XPATH, using="/html/body/form/section[2]/div[24]/button")
    @CacheLookup
    WebElement submit;
   
   
    public void name(String nam, String ema, String feed) {
        name.sendKeys(nam);
        email.sendKeys(ema);
        feedback.sendKeys(feed);
       
    }
   
    public void Fordot_pwd_FB() {
        submit.click();
    }
}
