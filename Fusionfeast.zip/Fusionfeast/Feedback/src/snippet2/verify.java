package snippet2;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import snippet.Page_obj;

public class verify {
	
	WebDriver driver;
	@Test
	public void FBLogin() {
		driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://localhost/fusion_fiest/review.php");
		Page_obj abcd= new Page_obj(driver);
		abcd.typeusername();
		abcd.typeemail();
		abcd.typeaddress();
		abcd.clickbutton();
	}

}
