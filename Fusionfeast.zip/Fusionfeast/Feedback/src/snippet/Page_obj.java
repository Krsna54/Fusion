package snippet;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_obj {
	
	WebDriver driver;
	
public Page_obj(WebDriver driver) {
		this.driver= driver;
	}
	
	public void typeusername() {
		driver.findElement(By.name("name")).sendKeys("Sona");
	}
	public void typeemail() {
		driver.findElement(By.name("email")).sendKeys("ss@mail.com");
		}
	
public void typeaddress() {

driver.findElement(By.name("feedback")).sendKeys("Great impact");

}
public void clickbutton() {

driver.findElement(By.name("submit")).click();
driver.close();
}
}

