package snippet;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;

public class login {

	public WebDriver driver;
	By uname= By.name("email");
	@Test
	public void FBLogin() {
		driver= new FirefoxDriver();
		driver.get("http://localhost/fusion_fiest/review.php");
		driver.manage().window().maximize();

		driver.findElement(By.name("name")).sendKeys("Sona");
	    
		driver.findElement(By.name("email")).sendKeys("ss@gmail.com");
        
	    driver.findElement(By.name("feedback")).sendKeys("Great impact");
	
	    driver.findElement(By.name("submit")).click();
	}
	public void onTestFailure(ITestResult obj) {
	System.out.println("Screenshot captured"+obj.toString());
}
	public void onTestStart(ITestResult obj) {
System.out.println("Testcase started"+ obj.toString());
}
	public void onTestSuccess(ITestResult obj) {
	System.out.println("Congrats Test case has been passed"+ obj.toString());
}
}
