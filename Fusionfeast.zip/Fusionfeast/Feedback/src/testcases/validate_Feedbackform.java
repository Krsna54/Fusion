package testcases;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import Helper.BrowserFactory;
import Pages.Login_pageNew;

public class validate_Feedbackform {

	@Test
    public void check() {
    WebDriver driver=BrowserFactory.start_browser("Firefox","http://localhost/Fusion_fiest/#Feedback.php");
    Login_pageNew login=PageFactory.initElements(driver, Login_pageNew.class);
    login.name("Aanya","Aanya@123gmail.com","Excellent");
    login.Fordot_pwd_FB();
    }
}
