package Other;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Datadriven {
	
	 private WebDriver driver;
 
	 	String Baseurl= "http://localhost/fusion_fiest/review.php";
		boolean name= false;
		boolean email= false;
 
 
	  private boolean acceptNextAlert = true;
 
	  private StringBuffer verificationErrors = new StringBuffer();
 
	
 
	@Before
 
	  public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.get(Baseurl);
		 }
 
 
	  @Test
 
	  public void testWeb() throws Exception {
		  	name= driver.findElement(By.name("name")).isDisplayed();
			driver.findElement(By.name("name")).sendKeys("Aastha");
			email = driver.findElement(By.name("email")).isDisplayed();
			driver.findElement(By.name("email")).sendKeys("Aastha1234@gmail.com");
			boolean feedback = driver.findElement(By.name("feedback")).isDisplayed();
			driver.findElement(By.name("feedback")).sendKeys("The menu is as my compatibility and the food is just so tasty");
			driver.findElement(By.name("submit")).click();
	  }
			@After
 
			  public void tearDown() throws Exception {
 
				driver.quit();
 
			  }
 
}