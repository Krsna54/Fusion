package snippet;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;

public class Login {

	public WebDriver driver;
	By uname= By.name("email");
	@Test
	public void FBLogin() {
		driver= new FirefoxDriver();
		driver.get("http://localhost/Fusion_fiest/booktable.php");
		driver.manage().window().maximize();
		driver.findElement(By.name("email")).sendKeys("abcd");
		driver.findElement(By.id("pass")).sendKeys("hello");
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[2]/div[2]/form/div/div[3]/button")).click();
		
	}
	public void onTestFailure(ITestResult obj) {
	System.out.println("Screenshot captured"+obj.toString());
}
	public void onTestStart(ITestResult obj) {
System.out.println("Testcase started"+ obj.toString());
}
	public void onTestSuccess(ITestResult obj) {
	System.out.println("Congrats Test case has been passed"+ obj.toString());
}
}
