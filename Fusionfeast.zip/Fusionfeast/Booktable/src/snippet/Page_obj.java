package snippet;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Page_obj {
	
	WebDriver driver;
	By uname= By.name("email");
	By password = By.id("pass");
	By button= By.xpath("/html/body/div[1]/div[1]/div[1]/div/div[2]/div[2]/form/div/div[3]/button");
			
public Page_obj(WebDriver driver) {
		this.driver= driver;
	}
	
	public void typeusername() {
		driver.findElement(uname).sendKeys("hi");
	}
	public void typepassword() {
		driver.findElement(password).sendKeys("hi123");
		}
public void clickbutton() {
	driver.findElement(button).click();
}

}