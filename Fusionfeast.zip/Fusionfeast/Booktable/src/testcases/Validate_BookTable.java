package testcases;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import Helper.BrowserFactory;
import Pages.Login_pageNew;
 
public class Validate_BookTable {
 
    @Test
    public void check() {
    WebDriver driver=BrowserFactory.start_browser("Firefox","http://localhost/Fusion_fiest/booktable.php");
    Login_pageNew login=PageFactory.initElements(driver, Login_pageNew.class);
    login.bookTable("pari","pari@123gmail.com","9310634930","12/12/2024","12:30","8");
    login.Fordot_pwd_FB();
 
   
 
    }
}
 