package Helper;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
 
public class BrowserFactory {
 
    static WebDriver driver;
    public static WebDriver start_browser(String browserName, String url) {
        if(browserName.equalsIgnoreCase("Firefox")){
            driver= (WebDriver) new FirefoxDriver();
        }else if(browserName.equalsIgnoreCase("Edge")) {
            System.setProperty("webdriver.edge.driver","C:\\Users\\maury\\Desktop\\edgedriver_win64 (1) 1");
            driver= (WebDriver) new EdgeDriver();
        }else if(browserName.equalsIgnoreCase("Chrome")) {
            driver= (WebDriver) new ChromeDriver();
        }
        driver.manage().window().maximize();
        driver.get(url);
        return driver;
    }
}
 