package Other;
 
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Datadriven {
	
	 private WebDriver driver;
 
	  public static String Baseurl= "http://localhost/Fusion_fiest/booktable.php";
 
	  private boolean acceptNextAlert = true;
 
	  private StringBuffer verificationErrors = new StringBuffer();
 
	  public Integer passCount = 0;
 
	  public Integer totalCount = 3;
 
	  public static String isNamePresent;
 
	  public static String isEmailPresent;
 
	  public static String isNumPresent;
 
	  public static boolean isDatePresent;
 
	  public static boolean isTimePresent = false;
 
	  public static boolean isTotalPresent = false;
 
	  public static boolean isSubmitButtonPresent = false;
 
 
 
	@Before
 
	  public void setUp() throws Exception {
	
		driver= new FirefoxDriver();
		driver.get(Baseurl);
		 }
 
 
	  @Test
 
	  public void testWeb() throws Exception {
		  
		    driver.findElement(By.name("name")).sendKeys("Sonam");
			System.out.println(isNamePresent);
 
			 driver.findElement(By.name("email")).sendKeys("shresthta@gmail.com");
			
			 driver.findElement(By.name("number")).sendKeys("7659876543");
			
			isDatePresent= driver.findElement(By.name("date")).isDisplayed();
		    driver.findElement(By.name("date")).sendKeys("12/1/2024");
		    
		    isTimePresent= driver.findElement(By.name("time")).isDisplayed();
		    driver.findElement(By.name("time")).sendKeys("12:15 AM");
           
		    isTotalPresent= driver.findElement(By.name("total")).isDisplayed();
			driver.findElement(By.name("total")).sendKeys("3");
			
			isSubmitButtonPresent= driver.findElement(By.name("submit")).isDisplayed();
			driver.findElement(By.name("submit")).click();
	  }
			@After
 
			  public void tearDown() throws Exception {
 
				driver.quit();
 
			  }
 
}