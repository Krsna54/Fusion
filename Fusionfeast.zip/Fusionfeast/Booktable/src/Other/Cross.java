package Other;
 
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
 
public class Cross {
	WebDriver driver;
	@Test
	@Parameters("Browser")
	public void cbrowser(String Browser) {
		if(Browser.equalsIgnoreCase("FF")) {
			driver = new FirefoxDriver();
			driver.get("http://localhost/Fusion_fiest/booktable.php");
			driver.close();
			}
		else if (Browser.equalsIgnoreCase("Chrome")) {
			driver= new ChromeDriver();
			driver.get("http://localhost/Fusion_fiest/booktable.php");
			driver.close();
			}
		else if (Browser.equalsIgnoreCase("Edge")) {
			System.setProperty("webdriver.edge.driver","C:\\Users\\Shresthta Arora\\Desktop\\edgedriver_win64 (1) 1\\msedgedriver.exe");
			driver=new EdgeDriver();
			driver.get("http://localhost/Fusion_fiest/booktable.php");
			driver.close();
				  
		}
	}
 
}