package Pages;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
 
public class Login_pageNew {
 
    WebDriver driver;
    public Login_pageNew(WebDriver driver) {
        this.driver= driver;
                }
    @FindBy(name= "name")
    @CacheLookup
    WebElement uname;
    @FindBy(how=How.NAME, using= "email")
    @CacheLookup
    WebElement email;
    @FindBy(how=How.NAME, using= "number")
    @CacheLookup
    WebElement num;
    @FindBy(how=How.XPATH, using= "/html/body/form/div/input[4]")
    @CacheLookup
    WebElement date;
    @FindBy(how=How.NAME, using= "time")
    @CacheLookup
    WebElement time;
    @FindBy(how=How.NAME, using= "total")
    @CacheLookup
    WebElement total;
    @FindBy(how=How.NAME, using= "submit")
    @CacheLookup
    WebElement submit;
  
    public void bookTable(String nam, String emai, String numb, String da,String ti, String tot) {
        uname.sendKeys(nam);
        email.sendKeys(emai);
        num.sendKeys(numb);
        date.sendKeys(da);
       time.sendKeys(ti);
       total.sendKeys(tot);
    }
 
    public void Fordot_pwd_FB() {
        submit.click();
    }
}