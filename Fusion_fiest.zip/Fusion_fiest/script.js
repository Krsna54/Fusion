document.addEventListener('DOMContentLoaded', function () {
    const itemsContainer = document.getElementById('items-container');

    itemsContainer.addEventListener('click', function (event) {
        const targetButton = event.target.closest('.add-to-cart-btn');

        if (targetButton) {
            const itemId = targetButton.getAttribute('data-id');
            const itemName = targetButton.getAttribute('data-name');
            const itemPrice = parseFloat(targetButton.getAttribute('data-price'));
       
            // Send data to server using AJAX
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'plate.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    // Refresh the page to update the cart display
                    window.location.reload();
                }
            };
            xhr.send('action=addToCart&id=' + itemId + '&name=' + itemName + '&price=' + itemPrice);
        }
    });
});