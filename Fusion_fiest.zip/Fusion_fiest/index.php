<?php
include("first.php");
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style.css">
    <title> Fusion Feast  </title> 
</head>
<body>
<form action="" method="POST">
    <nav class="navbar">
        <ul class="nav-list">
            <div class="logo"><img src="lo_go.png" alt="logo"></div>
            <li class="nav-item active"> <a href="index.php"> Home</a> </li>
            <li> <a href="menu.html"> Menu</a> </li>
            <li> <a href="about.html"> About us</a> </li>
            <li> <a href="#Contact"> Contact us</a> </li>
            <li> <a href="#Feedback"> Reviews </a> </li>
            <li> <a href="plate.php"> Plate </a> </li>
        </ul>
    </nav>
    <div class="main  bg " id="Home">
        <div class="first">
          <class class="trans"> </class>  
            
            <div class="mask" style="background-color: rgba(255, 255, 255, 0.3);">
                <div class="h-100">
                    <p class="title ">Welcome to Fusion Feast..</p>
                    <p class="content1 bold">An Authentic Mediterranean Restaurant</p>
                    <p class="content2 bold">We take pride in serving the finest homemade and authentic dishes.</p>
                    <p class="content2 bold">Nothing brings people together like good food.</p>
                    <p class="content2 bold">Creativity is always on our menu.</p>
                  </div>     
                </div> 
         
          <div class="button">
            
            <button class="btnv"><a href="menu.html">Order Now</a></button>
            <button class="btnv"><a href="booktable.php">Book Table</a></button>
        </div>        
        </div>
    </div>
    </section> 
    <section class="tour-packages">
        <div class="container">
            <h2 class="text-center mb-5 title">We have ...</h2>
            <div class="row">
            <div class="col-md-4 mb-4">
                <div class="card tour-card" data-toggle="tooltip" data-placement="top" title="Click to view details">
                <img src="MicrosoftTeams-image (20).png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Fast Food</h5>
                    <p class="card-text"></p>
                    <a href="menu.html" class="btn btn-primary btn-book-now"> More </a>
                    
                </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card tour-card" data-toggle="tooltip" data-placement="top" title="Click to view details">
                <img src="MicrosoftTeams-image (21).png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Drinks</h5>
                    <p class="card-text"></p>
                    <a href="menu.html" class="btn btn-primary btn-book-now"> More </a>
                    
                </div>
                </div>
            </div>
            <div class="col-md-4 mb-4">
                <div class="card tour-card" data-toggle="tooltip" data-placement="top" title="Click to view details">
                <img src="MicrosoftTeams-image (22).png" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Main Course</h5>
                    <p class="card-text"></p>
                    <a href="menu.html" class="btn btn-primary btn-book-now"> More </a>
                </div>
                </div>
            </div>
        </div>
        </section>    

    <section class="feedback" id="Feedback">
        <div class="title">Reviews..</div>
        <div class="content1">Saloni</div>
        <div class="content2">I had a wonderful experience and I would definitely recommend this place. I appreciate their warm hospitality.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Abhay</div>
        <div class="content2">The timing between courses was well-paced, allowing us to enjoy each dish without feeling rushed.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Ashutosh</div>
        <div class="content2">The restaurant's ambiance was delightful, creating a pleasant atmosphere for a dining experience.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Anushka</div>
        <div class="content2">It would be beneficial to have more vegetarian or vegan options on the menu for those with dietary restrictions.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Krish</div>
        <div class="content2">Good food, Fast service,
          Good staff,
          Cleanliness,
          Reasonable prices.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Shresthta Arora</div>
        <div class="content2">We thoroughly enjoyed our time at the restaurant and would recommend it to friends and family.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="content1">Krishna</div>
        <div class="content2">They offer the best of food that is absolutely clean and hygienic and also their staff is really polite and soft-spoken.</div>
        <div class="content1">&starf; &starf; &starf; &starf; &starf;</div>
        <div class="title">Add yours..</div>
        
        <div class="form">
         
            <td><input type="text" class="text" placeholder="Enter your Name" name="name" required></td>
            <input type="email" class="text" placeholder="Enter your Email" name="email"required >
            <textarea id="feedback" cols="30" rows="10" placeholder="Enter your Feedback" name="feedback" required></textarea>
            
                <button class="submit-btn" name="submit">Submit</button>
            
         
        </div>
        
    </section>
    
    <footer class="footer" id="Contact">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <h4>Get in Touch</h4>
              <ul class="list-unstyled">
                <li><i class="fa fa-map-marker"></i> Address: Main Bazar , kandaghat <br> Solan , Himachal Pradesh <br>INDIA , 173215</be></li>
                <li><i class="fa fa-phone"></i> Phone: +91 8877346520</li>
                <li><i class="fa fa-envelope"></i> Email: info@fusionfeast.com</li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>Follow Us</h4>
              <ul class="list-unstyled">
                <li class="twitter-icon">
                  <a href="https://twitter.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-twitter"><i class="fa fa-twitter"></i>Twitter</a></li></i>
                  </a>
                  </li>
                  <li class="facebook-icon">
                  <a href="https://www.facebook.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-facebook-1"><i class="fa fa-facebook"></i> Facebook</a></li></i>
                  </a>
                  </li>
                  <li class="insatgram-icon">
                    <a href="https://www.instagram.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                      <i class="icon-instagram-1"><i class="fa fa-instagram"></i>Instagram</a></li></i>
                    </a>
                    </li>
                  <li class="youtube-icon">
                  <a href="https://www.youtube.com/majestic_himachal" target="_blank"
                      rel="noreferrer noopener">
                     <i class="youtube-icon-1"><i class="fa fa-youtube-icon"></i> YouTube</a></li></i>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>WhatsApp Us</h4>
              <div class="whatsapp-btn">
                <a href="https://wa.me/+917591058332" target="_blank"><i class="fa fa-whatsapp"></i> Chat with Us</a>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 text-center">
              <p>&copy; 2022 Fusion Feast. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
      <style>
        .submit-btn{
   width: 100%;
   padding:12px;
   font-size: 17px;
   background: #27ae60;
   color:#fff;
   margin-top: 5px;
   cursor: pointer;
 }
  
.submit-btn:hover{
   background: #2ecc71;
 }
        </style>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</form>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$n=$_POST['name'];
$e=$_POST['email'];
$f=$_POST['feedback'];

$query="insert into review values('$n','$e','$f')";
$data=mysqli_query($con,$query);

if($data)
{
  echo "Data stored successfully";
}
else
{
  echo "Failed to store data";
}
}
?>