<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style.css">
    <title>Reviews</title>
</head>
<body>
<form action="" method="POST">
<nav class="navbar ">
        <ul class="nav-list">
            <div class="logo"><img src="lo_go.png" alt="logo"></div>
            <li> <a href="index.php"> Home</a> </li>
            <li> <a href="menu.html"> Menu</a> </li>
            <li> <a href="about.html"> About us</a> </li>
            <li> <a href="#Contact"> Contact us</a> </li>
            <li> <a href="review.php"> Reviews</a> </li>
            <li> <a href="plate.php"> Plate </a> </li>
        </ul>
    </nav>
    <div class="tit title">All Reviews..</div>
    <div class="tbl"> 
    <table border="3"> 

        <tr>
        <th> Name </th> 
       
        <th> Feedback </th>
        
        </tr>
  
        <?php
        
        
        include("first.php");
        error_reporting(0);
        
        
        $query = "select * from review";
        $data= mysqli_query($con, $query);
        $total= mysqli_num_rows($data);
        
        
        echo $result['print anything'];
        
        
        
        if ($total!=0)
        { 
            
        while (($result= mysqli_fetch_assoc($data)))
        
            {
        echo"
        <tr>
        <td>".$result[ 'name']."</td>
      
        <td>".$result[ 'feedback']."</td>
        </tr>
        ";
        }
        }
        
        else
        {
        echo "No records found";
        }
        
        
        
        ?>
        </table>
        </div>
        <div class="review">
        <div class="title ">Add yours..</div>
        
        <div class="form">
         
            <td><input type="text" class="text" placeholder="Enter your Name" name="name" required></td>
            <input type="email" class="text" placeholder="Enter your Email" name="email" required>
            <textarea id="feedback" cols="30" rows="10" placeholder="Enter your Feedback" name="feedback"required ></textarea>
            
                <button class="submit-btn b" name="submit">Submit</button>
            
            </div>
        </div>
        <footer class="footer" id="Contact">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <h4>Get in Touch</h4>
              <ul class="list-unstyled">
                <li><i class="fa fa-map-marker"></i> Address: Main Bazar , kandaghat <br> Solan , Himachal Pradesh <br>INDIA , 173215</be></li>
                <li><i class="fa fa-phone"></i> Phone: +91 8877346520</li>
                <li><i class="fa fa-envelope"></i> Email: info@fusionfeast.com</li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>Follow Us</h4>
              <ul class="list-unstyled">
                <li class="twitter-icon">
                  <a href="https://twitter.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-twitter"><i class="fa fa-twitter"></i>Twitter</a></li></i>
                  </a>
                  </li>
                  <li class="facebook-icon">
                  <a href="https://www.facebook.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-facebook-1"><i class="fa fa-facebook"></i> Facebook</a></li></i>
                  </a>
                  </li>
                  <li class="insatgram-icon">
                    <a href="https://www.instagram.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                      <i class="icon-instagram-1"><i class="fa fa-instagram"></i>Instagram</a></li></i>
                    </a>
                    </li>
                  <li class="youtube-icon">
                  <a href="https://www.youtube.com/majestic_himachal" target="_blank"
                      rel="noreferrer noopener">
                     <i class="youtube-icon-1"><i class="fa fa-youtube-icon"></i> YouTube</a></li></i>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>WhatsApp Us</h4>
              <div class="whatsapp-btn">
                <a href="https://wa.me/+917591058332" target="_blank"><i class="fa fa-whatsapp"></i> Chat with Us</a>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 text-center">
              <p>&copy; 2022 Fusion Feast. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
      <style>
        .submit-btn{
   width: 100%;
   padding:12px;
   font-size: 17px;
   background: #27ae60;
   color:#fff;
   margin-top: 5px;
   cursor: pointer;
 }
  
.submit-btn:hover{
   background: #2ecc71;
 }
        </style>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    </form>
</body>
</html>
<?php
if(isset($_POST['submit']))
{
$n=$_POST['name'];
$e=$_POST['email'];
$f=$_POST['feedback'];

$query="insert into review values('$n','$e','$f')";
$data=mysqli_query($con,$query);

if($data)
{
  echo "Data stored successfully";
}
else
{
  echo "Failed to store data";
}
}
?>