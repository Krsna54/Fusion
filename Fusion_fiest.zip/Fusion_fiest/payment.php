<?php
include("first.php");
error_reporting(0);
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style.css">
    <title>Payment</title>
</head>
<body>
    <nav class="navbar">
        <ul class="nav-list">
            <div class="logo"><img src="lo_go.png" alt="logo"></div>
            <li class="nav-item active"> <a href="index.php"> Home</a> </li>
            <li> <a href="menu.html"> Menu</a> </li>
            <li> <a href="about.html"> About us</a> </li>
            <li> <a href="#Contact"> Contact us</a> </li>
            <li> <a href="review.php"> Reviews </a> </li>
            <li> <a href="plate.php"> Plate </a> </li>
        </ul>
    </nav>
    <div class="containe">
 
        <form action="" method="POST">
     
            <div class="rows">
     
                <div class="col">
     
                    <h3 class="content1 lev h">Delivery Details</h3>
     
                    <div class="inputBox">
                        <span>Full Name :</span>
                        <input type="text" placeholder="Enter your name" name="name"required>
                    </div>
     
                    <div class="inputBox">
                        <span>Phone Number :</span>
                        <input type="phone number" placeholder="Enter your phone number" name="num"required>
                    </div>
                    <div class="inputBox">
                        <span>Address :</span>
                        <input type="text" placeholder="Enter your address" name="address"required>
                    </div>
                 
                        <div class="inputBox">
                            <span>PIN Code :</span>
                            <input type="text" placeholder="Enter the pin code" name="pin"required>
                        </div>
                    </div>
                    <button class="submit-btn" name="submit">Click to Proceed</button>
                </div>
            </div>
     
        </form>
     
    </div>    
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600&display=swap');
 
 *{
   font-family: 'Poppins', sans-serif;
   margin:0; padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-transform: capitalize;
   transition: all .2s linear;
 }
  
 .containe{
   display: flex;
   justify-content: center;
   align-items: center;
   padding:25px;
   min-height: 100vh;
   background-color: antiquewhite;
 }
  
 .containe form{
   padding:20px;
   width:700px;
   background: #fff;
   box-shadow: 0 5px 10px rgba(0,0,0,.1);
 }
  
 .containe form .rows{
   display: flex;
   flex-wrap: wrap;
   gap:15px;
 }
  
 .containe form .rows .col{
   flex:1 1 250px;
 }
  
 .containe form .rows .col .title{
   font-size: 20px;
   color:#333;
   padding-bottom: 5px;
   text-transform: uppercase;
 }
  
 .containe form .rows .col .inputBox{
   margin:15px 0;
 }
  
 .containe form .rows .col .inputBox span{
   margin-bottom: 10px;
   display: block;
 }
  
 .containe form .rows .col .inputBox input{
   width: 100%;
   border:1px solid #ccc;
   padding:10px 15px;
   font-size: 15px;
   text-transform: none;
 }
  
 .containe form .rows .col .inputBox input:focus{
   border:1px solid #000;
 }
  
 .containe form .rows .col .flex{
   display: flex;
   gap:15px;
 }
  
 .containe form .rows .col .flex .inputBox{
   margin-top: 5px;
 }
  
 .containe form .rows .col .inputBox img{
   height: 34px;
   margin-top: 5px;
   filter: drop-shadow(0 0 1px #000);
 }
  
 .containe form .submit-btn{
   width: 100%;
   padding:12px;
   font-size: 17px;
   background: #27ae60;
   color:#fff;
   margin-top: 5px;
   cursor: pointer;
 }
  
 .containe form .submit-btn:hover{
   background: #2ecc71;
 }
 .in img{
     width: 10px;
 }
 .h{
  padding-left:120px;
 }
</style>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>

</body>
</html>
<?php
if(isset($_POST['submit']))
{
$n=$_POST['name'];
$no=$_POST['num'];
$d=$_POST['address'];
$t=$_POST['pin'];


$query="insert into bill values('$n','$no','$d','$t')";
$data=mysqli_query($con,$query);
if($data)
{
  header("Location: thank.html");
}
else
{
  echo "Failed to order";
}
}
ob_end_flush();
?>