<?php

include("first.php");
error_reporting(0);
ob_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style.css">
    <title>Book Table</title>
</head>
<body>
<form action="" method="POST">
    <nav class="navbar ">
        <ul class="nav-list">
            <div class="logo"><img src="lo_go.png" alt="logo"></div>
            <li> <a href="index.php"> Home</a> </li>
            <li> <a href="menu.html"> Menu</a> </li>
            <li> <a href="about.html"> About us</a> </li>
            <li> <a href="#Contact"> Contact us</a> </li>
            <li> <a href="review.php"> Reviews</a> </li>
            <li> <a href="plate.php"> Plate </a> </li>
        </ul>
    </nav>
    <div class="form book">
        <div class="title">
        <br >Book A Table..</br>
        </div>
        <td>Name<input type="text" placeholder="Enter your name" name="name" required></td>
        <td>Email <input type="email" placeholder="Enter your Email" name="email" required></td>
        <td>Phone No. <input type="text" placeholder="Enter your Phone number" name="number" required></td>
        <td>Date <input type="date" placeholder="Enter date" name="date" required></td>
        <td>Time <input type="time" placeholder="Enter time" name="time" required></td>
        <td>No of People <input type="text" placeholder="Total number" name="total" required></td>
        <button class="btnv reff" name="submit" onclick="header()">Book Table</button>
       
    </div>

    <footer class="footer" id="Contact">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <h4>Get in Touch</h4>
              <ul class="list-unstyled">
                <li><i class="fa fa-map-marker"></i> Address: Main Bazar , kandaghat <br> Solan , Himachal Pradesh <br>INDIA , 173215</be></li>
                <li><i class="fa fa-phone"></i> Phone: +91 8877346520</li>
                <li><i class="fa fa-envelope"></i> Email: info@fusionfeast.com</li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>Follow Us</h4>
              <ul class="list-unstyled">
                <li class="twitter-icon">
                  <a href="https://twitter.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-twitter"><i class="fa fa-twitter"></i>Twitter</a></li></i>
                  </a>
                  </li>
                  <li class="facebook-icon">
                  <a href="https://www.facebook.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-facebook-1"><i class="fa fa-facebook"></i> Facebook</a></li></i>
                  </a>
                  </li>
                  <li class="insatgram-icon">
                    <a href="https://www.instagram.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                      <i class="icon-instagram-1"><i class="fa fa-instagram"></i>Instagram</a></li></i>
                    </a>
                    </li>
                  <li class="youtube-icon">
                  <a href="https://www.youtube.com/majestic_himachal" target="_blank"
                      rel="noreferrer noopener">
                     <i class="youtube-icon-1"><i class="fa fa-youtube-icon"></i> YouTube</a></li></i>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>WhatsApp Us</h4>
              <div class="whatsapp-btn">
                <a href="https://wa.me/+917591058332" target="_blank"><i class="fa fa-whatsapp"></i> Chat with Us</a>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 text-center">
              <p>&copy; 2022 Fusion Feast. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</form>
</body>
</html>
<?php

if(isset($_POST['submit']))
{
$n=$_POST['name'];
$e=$_POST['email'];
$no=$_POST['number'];
$d=$_POST['date'];
$t=$_POST['time'];
$to=$_POST['total'];

$query="insert into booktable values('$n','$e','$no','$d','$t','$to')";
$data=mysqli_query($con,$query);
if($data)
{
  header("Location: thankyou.html");
  


}
else
{
  echo "Failed to store data";
}
}
ob_end_flush(); 
?>
