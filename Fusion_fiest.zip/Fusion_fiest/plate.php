<?php

session_start();
error_reporting(0);
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : array();

function addToCart($id, $name, $price, $image) {
    $item = array('id' => $id, 'name' => $name, 'price' => $price);
    $_SESSION['cart'][] = $item;
}

function clearCart() {
    $_SESSION['cart'] = array();
}

function deleteCartItem($itemId) {
    foreach ($_SESSION['cart'] as $key => $item) {
        if ($item['id'] === $itemId) {
            unset($_SESSION['cart'][$key]);
            break;
        }
    }
}
function calculateTotalItems(){
    $totalItems=0;
    foreach ($_SESSION['cart'] as $item){
        $totalItems += $item['price'];
    }
    return $totalItems;
}
if (isset($_POST['action'])) {
    if ($_POST['action'] === 'addToCart') {
        $itemId = $_POST['id'];
        $itemName = $_POST['name'];
        $itemPrice = $_POST['price'];
        $itemImage = $_POST['image'];
        addToCart($itemId, $itemName, $itemPrice, $itemImage);
    } elseif ($_POST['action'] === 'clearCart') {
        clearCart();
    } elseif ($_POST['action'] === 'deleteItem') {
        $deleteItemId = $_POST['id'];
        deleteCartItem($deleteItemId);
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="Style.css">
    <title>Plate</title>
</head>
<body>
    <nav class="navbar ">
        <ul class="nav-list">
            <div class="logo"><img src="lo_go.png" alt="logo"></div>
            <li> <a href="index.php"> Home</a> </li>
            <li> <a href="menu.html"> Menu</a> </li>
            <li> <a href="about.html"> About us</a> </li>
            <li> <a href="#Contact"> Contact us</a> </li>
            <li> <a href="review.php"> Reviews</a> </li>
            <li> <a href="plate.php"> Plate </a> </li>
        </ul>
    </nav>
    <div class="cart">
      <p class="title">Cart..</p>
    <div id="cart-container">
        <?php foreach ($cart as $item): ?>
            <div class="cart-item form">
            <form action="" method="post" >
                <p><?php echo $item['name']; ?> - ₹<?php echo $item['price']; ?></p>
                
                    <input type="hidden" name="action" value="deleteItem">
                    <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
                    <button type="submit" class="delete">Delete</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="form">
    <form action="" method="post">
    <p>Total: ₹<?php echo calculateTotalItems(); ?></p>
    <button type="submit"class="pro"><a href="payment.php">Proceed</a></button>
    <input type="hidden" name="action" value="clearCart">
    <button type="submit" class="delete">Clear Cart</button>
    </form>
    </div>
    <button class="submit-btn"><a href="menu.html">Continue Shopping</a></button>
    </div>
    <script src="script.js"></script>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;300;400;500;600&display=swap');
 
 *{
   font-family: 'Poppins', sans-serif;
   margin:0; padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-transform: capitalize;
   transition: all .2s linear;
 }
  
 .cart{
   display: flex;
   justify-content: center;
   align-items: center;
   padding:25px;
   min-height: 100vh;
   background-color: antiquewhite;
   flex-direction: column;
 }
  
 .cart form{
  padding: 25px;
    width: 400px;
   background: #fff;
   box-shadow: 0 5px 10px rgba(0,0,0,.1);
   padding-top:32px;
   padding-bottom:32px;
   font-size:22px;

 }

 .submit-btn {
   width: 20%;
   padding:12px;
   font-size: 17px;
   background: #00ffad;
   color:#fff;
   margin-top: 5px;
   cursor: pointer;
   text-decoration: none;
   border: 2px solid rgb(0, 55, 255);
    border-radius: 30px;
 }
  
 .submit-btn:hover{
   background: #2ecc71;
 }
 .submit-btn a{
  text-decoration: none;
  
 }
 .delete{ 
    width: 35%;
   padding:12px;
   font-size: 17px;
   background: #00f1fd;
   color:black;
   margin-top: 5px;
   cursor: pointer;
   text-decoration: none;
   border: 2px solid rgb(0, 55, 255);
    border-radius: 30px;
 }
 .delete:hover{
  background: #2ecc71;
 }
 
  p {
    margin-top: 0;
    margin-bottom: 4rem;
}
.pro{
  width: 35%;
   padding:12px;
   margin-right:20px;
   font-size: 17px;
   background: #00f1fd;
   color:black;
   margin-top: 5px;
   cursor: pointer;
   text-decoration: none;
   border: 2px solid rgb(0, 55, 255);
    border-radius: 30px;
  
}
.pro:hover{
  background: #2ecc71;
 }
 .form {
    align-items: center;
    width: 100%;
    display: grid;
    justify-content: center;
    padding: 25px 0px;
    border-color: aquamarine;
    text-align: center;
}

</style>
    <footer class="footer" id="Contact">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <h4>Get in Touch</h4>
              <ul class="list-unstyled">
                <li><i class="fa fa-map-marker"></i> Address: Main Bazar , kandaghat <br> Solan , Himachal Pradesh <br>INDIA , 173215</be></li>
                <li><i class="fa fa-phone"></i> Phone: +91 8877346520</li>
                <li><i class="fa fa-envelope"></i> Email: info@fusionfeast.com</li>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>Follow Us</h4>
              <ul class="list-unstyled">
                <li class="twitter-icon">
                  <a href="https://twitter.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-twitter"><i class="fa fa-twitter"></i>Twitter</a></li></i>
                  </a>
                  </li>
                  <li class="facebook-icon">
                  <a href="https://www.facebook.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                    <i class="icon-facebook-1"><i class="fa fa-facebook"></i> Facebook</a></li></i>
                  </a>
                  </li>
                  <li class="insatgram-icon">
                    <a href="https://www.instagram.com/taxiinhimachal" target="_blank" rel="noreferrer noopener">
                      <i class="icon-instagram-1"><i class="fa fa-instagram"></i>Instagram</a></li></i>
                    </a>
                    </li>
                  <li class="youtube-icon">
                  <a href="https://www.youtube.com/majestic_himachal" target="_blank"
                      rel="noreferrer noopener">
                     <i class="youtube-icon-1"><i class="fa fa-youtube-icon"></i> YouTube</a></li></i>
              </ul>
            </div>
            <div class="col-md-4">
              <h4>WhatsApp Us</h4>
              <div class="whatsapp-btn">
                <a href="https://wa.me/+917591058332" target="_blank"><i class="fa fa-whatsapp"></i> Chat with Us</a>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 text-center">
              <p>&copy; 2022 Fusion Feast. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>