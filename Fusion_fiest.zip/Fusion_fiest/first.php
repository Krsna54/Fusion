<?php
$servername="localhost";
$username = "root";
$password="";
$dbname = "fusion";
$con = mysqli_connect($servername,$username,$password,$dbname);
if($con)
{
    //echo "Connection Ok";
}
else
{
    echo "Connection Failed ".mysqli_connect_error();
}
?>